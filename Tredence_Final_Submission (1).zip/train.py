import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt

class PrunableLinear(nn.Module):
    def __init__(self, in_f, out_f):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(out_f, in_f)*0.01)
        self.bias = nn.Parameter(torch.zeros(out_f))
        self.gate_scores = nn.Parameter(torch.randn(out_f, in_f))

    def forward(self, x):
        gates = torch.sigmoid(self.gate_scores)
        return F.linear(x, self.weight * gates, self.bias)

class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = PrunableLinear(3072, 512)
        self.fc2 = PrunableLinear(512, 10)

    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)

transform = transforms.Compose([transforms.ToTensor()])
trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=64, shuffle=True)

model = Net()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
criterion = nn.CrossEntropyLoss()

lambda_val = 0.001

for epoch in range(2):
    for inputs, labels in trainloader:
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        sparsity = 0
        for layer in model.modules():
            if isinstance(layer, PrunableLinear):
                sparsity += torch.sum(torch.sigmoid(layer.gate_scores))

        loss = loss + lambda_val * sparsity

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

print("Training Done")

# Sparsity calculation
total, zero = 0, 0
for layer in model.modules():
    if isinstance(layer, PrunableLinear):
        gates = torch.sigmoid(layer.gate_scores)
        total += gates.numel()
        zero += torch.sum(gates < 1e-2).item()

print("Sparsity:", 100 * zero / total)

# Plot
all_gates = []
for layer in model.modules():
    if isinstance(layer, PrunableLinear):
        all_gates.extend(torch.sigmoid(layer.gate_scores).detach().cpu().numpy().flatten())

plt.hist(all_gates, bins=50)
plt.title("Gate Distribution")
plt.savefig("gate_plot.png")
