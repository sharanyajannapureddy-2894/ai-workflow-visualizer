# Self-Pruning Neural Network (Tredence Submission)

## Overview
This project implements a neural network that learns to prune itself during training using learnable gates.

## Features
- Custom PrunableLinear Layer
- L1 Sparsity Regularization
- CIFAR-10 Training
- Sparsity vs Accuracy Analysis
- Gate Distribution Visualization

## Run
pip install torch torchvision matplotlib
python train.py

## Output
- Prints training loss
- Calculates sparsity
- Generates gate distribution plot

## Author
Sharanya
